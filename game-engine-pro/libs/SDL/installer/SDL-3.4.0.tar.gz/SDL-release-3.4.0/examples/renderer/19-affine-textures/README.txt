This example creates an SDL window and renderer, and uses
SDL_RenderTextureAffine to draw a 3D cube using only 2D rendering operations.

