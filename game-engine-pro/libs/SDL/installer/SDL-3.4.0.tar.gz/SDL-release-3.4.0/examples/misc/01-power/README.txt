This example code reports power status (plugged in, battery level, etc).

Note that only Chrome-based browsers support this API currently. Firefox and
Safari will report this as unknown, but this may change later!
